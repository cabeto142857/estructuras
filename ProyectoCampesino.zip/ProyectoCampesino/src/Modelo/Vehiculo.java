/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Carlo
 */


public class Vehiculo {
    private String cedulaTransportador;
    private String placa;
    private String capacidad;
    private double capacidaddisponible;
    

    public Vehiculo(String cedulaTransportador, String placa) {
        
        this.cedulaTransportador = cedulaTransportador;
        this.placa = placa;
    }

    @Override
    public String toString() {
        return cedulaTransportador + "," + placa;
    }
}
