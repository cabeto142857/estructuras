/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Carlo
 */


public class Transportador {
    private String nombre;
    private String apellido;
    private String cedula;
    private String telefono;

    public Transportador(String nombre, String apellido, String cedula, String telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.telefono = telefono;
    }

    public String getCedula() {
        return cedula;
    }

    @Override
    public String toString() {
        return nombre + "," + apellido + "," + cedula + "," + telefono;
    }
}
