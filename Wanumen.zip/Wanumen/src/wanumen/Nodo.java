package wanumen;

public class Nodo {
    public String nombre = "";
    public Nodo sig = null;
    
    public Nodo(String parNombre){
        nombre = parNombre;
    }
    
    public void imprimir(){
        System.out.println("Nombre = "+nombre);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Nodo getSig() {
        return sig;
    }

    public void setSig(Nodo sig) {
        this.sig = sig;
    }
    
}
