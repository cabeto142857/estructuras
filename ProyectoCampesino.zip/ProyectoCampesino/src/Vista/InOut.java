/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author Carlo
 */


import Modelo.Campesino;
import Modelo.Cultivo;
  import Modelo.Transportador;
 import Modelo.Vehiculo;

import javax.swing.*;
import java.awt.*;

  import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
   import java.io.*;

public class InOut {

    
    private final String rutarchivocampesinos = "src/campesinos.txt";
   
    private final String rutarchivotransportadores = "src/transportadores.txt";
    private final String rutarchivocultivos = "src/cultivos.txt";
      private final String rutarchivovehiculos = "src/vehiculos.txt";
    
      private final String rutarchivogastos = "src/gastos.txt";

    
    
    
    public void mostrarMenuPrincipal() {
        
        JFrame frame = new JFrame("PROYECTO CAMPESINO ");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(485, 300);
        
        JPanel panel = new JPanel();
        frame.add(panel);
        colocarComponentesMenuPrincipal(panel);
        
        frame.setVisible(true);
    }

    private void colocarComponentesMenuPrincipal(JPanel panel) {
        
        panel.setLayout(new GridLayout(3, 1,1,7));

        JButton campesinoButton = new JButton("CAMPESINO");
        campesinoButton.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarMenuCampesino();
            }
        });
        panel.add(campesinoButton);

        JButton transportadorButton = new JButton("TRANSPORTADOR");
        transportadorButton.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarMenuTransportador();
            }
        });
        panel.add(transportadorButton);

        JButton salirButton = new JButton("SALIR");
        salirButton.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        panel.add(salirButton);
    }

    
    public void mostrarMenuCampesino() {
        
        JFrame frame = new JFrame("  BIENVENIDO");
        frame.setSize(485, 684);
        JPanel panel = new JPanel();
        frame.add(panel);
        colocarComponentesMenuCampesino(panel);
        frame.setVisible(true);
    }

    private void colocarComponentesMenuCampesino(JPanel panel) {
        panel.setLayout(new GridLayout(8, 1,1,7));

        JButton botonRegistroc = new JButton("REGISTRARSE");
        botonRegistroc.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarCampesino();
            }
        });
        panel.add(botonRegistroc);

        JButton cargarCultivo = new JButton("CARGAR CULTIVO");
        cargarCultivo.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarCultivo();
            }
        });
        panel.add(cargarCultivo);

        JButton verCultivos = new JButton("Ver Cultivos");
        verCultivos.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                verCultivos();
            }
        });
        panel.add(verCultivos);
        
         JButton programart = new JButton("PROGRAMAR TRANSPORTE");
        programart.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
              
            }
        });
        
        panel.add(programart);
        
        JButton verTransportes = new JButton("VER transportes programados");
        verTransportes.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
             
            }
        });
        panel.add(verTransportes);
        
        JButton adminCultivos = new JButton("ADMINISTRAR CULTIVOS");
        botonRegistroc.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
        });
        panel.add(adminCultivos);
        
        
        JButton rentabilidad = new JButton("VER RENTABILIDAD ED CULTIVOS");
        botonRegistroc.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
        });
        panel.add(rentabilidad);
        

        JButton regresarc = new JButton("REGRESAR AL MENU PRINCIPAL");
        regresarc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarMenuPrincipal();
            }
        });
        panel.add(regresarc);
    }

    
    private void registrarCampesino() {
        
        JFrame frame = new JFrame("REGISTRAR");
        frame.setSize(485, 300);
        JPanel panel = new JPanel(new GridLayout(5, 2,1,7));

        JLabel nombreLabel = new JLabel("    NombreS :");
        JTextField nombreField = new JTextField();
        panel.add(nombreLabel);
        panel.add(nombreField);

        JLabel apellidoLabel = new JLabel("    Apellidos:");
        JTextField apellidoField = new JTextField();
        panel.add(apellidoLabel);
        panel.add(apellidoField);

        JLabel cedulaLabel = new JLabel("   CEdula:");
        JTextField cedulaField = new JTextField();
        panel.add(cedulaLabel);
        panel.add(cedulaField);

        JLabel telefonoLabel = new JLabel("   Teléfono:");
        JTextField telefonoField = new JTextField();
        panel.add(telefonoLabel);
        panel.add(telefonoField);

        JButton registrarButton = new JButton(" REGISTRAR");
        registrarButton.addActionListener(new ActionListener() {
            
            @Override
            
            public void actionPerformed(ActionEvent e) {
                Campesino campesino = new Campesino(nombreField.getText(), apellidoField.getText(),
                        cedulaField.getText(), telefonoField.getText());
                guardarCampesinoEnArchivo(campesino);

                JOptionPane.showMessageDialog(null, "Registro exitso  ");
                frame.dispose();
            }
        });
        panel.add(registrarButton);

        frame.add(panel);
        frame.setVisible(true);
    }

    private void guardarCampesinoEnArchivo(Campesino campesino) {
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutarchivocampesinos, true))) {
            
            writer.write(campesino.toString());
            
            writer.newLine();
            
        } catch (IOException e) {
            
            
        }
    }

   
    private void cargarCultivo() {
       
      String cedula = JOptionPane.showInputDialog("Ingrese su CEdula:");  

        if (buscarCampesinoPorCedula(cedula)) {
            
            JFrame frame = new JFrame("CARGAR CULTIVO");
            frame.setSize(485, 300);
            JPanel panel = new JPanel(new GridLayout(2, 2,1,7));

            JLabel cultivoLabel = new JLabel("     Cultivo  :");
            JTextField cultivoField = new JTextField();
            panel.add(cultivoLabel);
            panel.add(cultivoField);

            JButton cargarButton = new JButton("CARGAR");
            cargarButton.addActionListener(new ActionListener() {
               
                @Override
                
                public void actionPerformed(ActionEvent e) {
                    
                    Cultivo cultivo = new Cultivo(cedula, cultivoField.getText());
                    guardarCultivoEnArchivo(cultivo);
                    
                      JOptionPane.showMessageDialog(null, "Cultivo cargado con éxito.");
                    
                      frame.dispose();
                }
            });
            panel.add(cargarButton);

            frame.add(panel);
            frame.setVisible(true);
            
            
        } else {
            
            JOptionPane.showMessageDialog(null, "Cédula no encontrada.");
        }
    }

    private boolean buscarCampesinoPorCedula(String cedula) {
        
        try (BufferedReader reader = new BufferedReader(new FileReader(rutarchivocampesinos))) {
            
            String linea;
            
            while ((linea = reader.readLine()) != null) {
                
                String[] datos = linea.split(",");
                
                if (datos[2].equals(cedula)) {
                    return true;
                }
            }
        } catch (IOException e) {
            
        }
        return false;
    }

    

    
                        private void verCultivos() {
        
                            String cedula = JOptionPane.showInputDialog("Ingrese su Cedula:");

        if (buscarCampesinoPorCedula(cedula)) {
            StringBuilder cultivos = new StringBuilder();
           
              try (BufferedReader reader = new BufferedReader(new FileReader(rutarchivocultivos))) {
                String linea;
                
                  while ((linea = reader.readLine()) != null) {
                    String[] datos = linea.split(",");
                    if (datos[0].equals(cedula)) {
                        cultivos.append("Cultivo: ").append(datos[1]).append("\n");
                    }
                }
            } catch (IOException e) {
               
            }

            JOptionPane.showMessageDialog(null, cultivos.toString(), "Cultivos", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "  Cédula no encontrada.");
        }
    }

  private void adminCultivos() {
        
      String cedula = JOptionPane.showInputDialog("Ingrese su CEdula:");  

        if (buscarCampesinoPorCedula(cedula)) {
            
           
            
               JFrame frame = new JFrame("");
            frame.setSize(485, 300);
            JPanel panel = new JPanel(new GridLayout(7, 2,1,17));

            JLabel nomgasto = new JLabel("       NOMBRE DEL GASTO:");
            JTextField nomgast = new JTextField();
            panel.add(nomgasto);
            panel.add(nomgast);
            
            JLabel valorgasto = new JLabel("       VALOR DEL GASTO:");
            JTextField valorgast = new JTextField();
            panel.add(valorgasto);
            panel.add(valorgast);

            
            JButton botoncargar = new JButton("Cargar");
           /* botoncargar.addActionListener(new ActionListener() {
                
                @Override
                public void actionPerformed(ActionEvent e) {
                    Campesino objcam = new Campesino(cedula, vehiculoplacat.getText());
                    guardarVehiculoEnArchivo(vehiculo);
                    JOptionPane.showMessageDialog(null, "Vehículo cargado con éxito.");
                    frame.dispose();
                }
            });
            panel.add(cargarButton);

            frame.add(panel);
            frame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Cédula no encontrada.");*/


           }}
   

        

    
    public void mostrarMenuTransportador() {
        
        JFrame frame = new JFrame("BIENVENIDO SEÑOR TRANSPORTADOOR");
        frame.setSize(485, 300);
        JPanel panel = new JPanel();
        frame.add(panel);
        colocarComponentesMenuTransportador(panel);
        frame.setVisible(true);
    }

    private void colocarComponentesMenuTransportador(JPanel panel) {
        panel.setLayout(new GridLayout(4, 1,1,7));

        JButton registroButton = new JButton("REGISTRARsE");
        registroButton.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarTransportador();
            }
        });
        panel.add(registroButton);

        JButton cargarVehiculoButton = new JButton("CARGAR VEHICULO");
        cargarVehiculoButton.addActionListener(new ActionListener(){
           
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarVehiculo();
            }
        });
        panel.add(cargarVehiculoButton);

        JButton verVehiculosButton = new JButton("VER VEHICULOS REGISTRADOS");
        verVehiculosButton.addActionListener(new ActionListener() {
            
            
            @Override
            public void actionPerformed(ActionEvent e) {
                verVehiculos();
            }
        });
        panel.add(verVehiculosButton);

        JButton regresarButton = new JButton("REGRESAR AL MENÚ ANTERIOR");
        regresarButton.addActionListener(new ActionListener() {
           
            
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarMenuPrincipal();
            }
        });
        panel.add(regresarButton);
    }

    
    private void registrarTransportador() {
        
        
        JFrame frame = new JFrame("REGISTRAR");
        frame.setSize(485, 300);
        JPanel panel = new JPanel(new GridLayout(5, 2,1,7));

        JLabel nombreLabel = new JLabel("              NombreS  :");
        JTextField nombreField = new JTextField();
        panel.add(nombreLabel);
        panel.add(nombreField);

        JLabel apellidoLabel = new JLabel("                Apellidos:");
        JTextField apellidoField = new JTextField();
        panel.add(apellidoLabel);
        panel.add(apellidoField);

        JLabel cedulaLabel = new JLabel("               numero de  Cédula:");
        JTextField cedulaField = new JTextField();
        panel.add(cedulaLabel);
        panel.add(cedulaField);

        JLabel telefonoLabel = new JLabel("                         Teléfono:");
        JTextField telefonoField = new JTextField();
        panel.add(telefonoLabel);
        panel.add(telefonoField);

        JButton registrarButton = new JButton("                 REGISTRAR");
        registrarButton.addActionListener(new ActionListener() {
            
            @Override
            
            public void actionPerformed(ActionEvent e) {
                Transportador transportador = new Transportador(nombreField.getText(), apellidoField.getText(),
                        cedulaField.getText(), telefonoField.getText());
                guardarTransportadorEnArchivo(transportador);

                JOptionPane.showMessageDialog(null, "Registro exitoso");
                frame.dispose();
            }
        });
        panel.add(registrarButton);

        frame.add(panel);
        frame.setVisible(true);
    }

    private void guardarTransportadorEnArchivo(Transportador transportador) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutarchivotransportadores, true))) {
            writer.write(transportador.toString());
            writer.newLine();
        } catch (IOException e) {
            
        }
    }

   
    private void cargarVehiculo() {
        String cedula = JOptionPane.showInputDialog("Ingrese su Cédula:");

        if (buscarTransportadorPorCedula(cedula)) {
            JFrame frame = new JFrame("Cargar Vehículo");
            frame.setSize(485, 300);
            JPanel panel = new JPanel(new GridLayout(7, 2,1,17));

            JLabel vehiculoplaca = new JLabel("       PLACA:");
            JTextField vehiculoplacat = new JTextField();
            panel.add(vehiculoplaca);
            panel.add(vehiculoplacat);
            
            JLabel vehiculocarga = new JLabel("       CAPACIDAD DE CARGA EN KG:");
            JTextField vehiculocargat = new JTextField();
            panel.add(vehiculocarga);
            panel.add(vehiculocargat);

            JButton cargarButton = new JButton("Cargar");
            cargarButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Vehiculo vehiculo = new Vehiculo(cedula, vehiculoplacat.getText());
                    guardarVehiculoEnArchivo(vehiculo);
                    JOptionPane.showMessageDialog(null, "Vehículo cargado con éxito.");
                    frame.dispose();
                }
            });
            panel.add(cargarButton);

            frame.add(panel);
            frame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Cédula no encontrada.");
        }
    }

    private boolean buscarTransportadorPorCedula(String cedula) {
        try (BufferedReader reader = new BufferedReader(new FileReader(rutarchivotransportadores))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos[2].equals(cedula)) {
                    return true;
                }
            }
        } catch (IOException e) {
            
        }
        return false;
    }

    private void guardarVehiculoEnArchivo(Vehiculo vehiculo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutarchivovehiculos, true))) {
            writer.write(vehiculo.toString());
            writer.newLine();
        } catch (IOException e) {
            
        }
    }


    private void verVehiculos() {
        String cedula = JOptionPane.showInputDialog("Ingrese su Cédula:");

        if (buscarTransportadorPorCedula(cedula)) {
            StringBuilder vehiculos = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(rutarchivovehiculos))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    String[] datos = linea.split(",");
                    if (datos[0].equals(cedula)) {
                        vehiculos.append("Vehículo: ").append(datos[1]).append("\n");
                    }
                }
            } catch (IOException e) {
               
            }

            JOptionPane.showMessageDialog(null, vehiculos.toString(), "Vehículos", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Cédula no encontrada.");
        }
    }
}
