package wanumen;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class EventoClick implements ActionListener{

    public void actionPerformed(ActionEvent e) {
        System.out.println("Presionaste Boton");
        String tDigitado = Ventana.caja.getText();
        Nodo nuevo = new Nodo(tDigitado);
        Wanumen.objLista.anadir(nuevo);
        String ca = Wanumen.objLista.devolverLista();
        Ventana.ta.setText(ca);
    }
    
}
