package wanumen;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;  
import javax.swing.JButton;  
import javax.swing.JFrame;  
import javax.swing.JLabel;  
import javax.swing.JPanel;  
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Ventana {  
    public static JFrame frame = new JFrame("Clase de Listas");          
    public static JPanel panelArriba = new JPanel();    
    public static JPanel panelCentro = new JPanel();
    public static JTextField caja = new JTextField(10);
    public static JButton boton = new JButton("Ingresar");
    public static JPanel panelAbajo = new JPanel();
    public static EventoClick even = new EventoClick();
    public static JTextArea ta = new JTextArea(10,10);
    
    public static void iniciarVentana() {       
        panelArriba.setBackground(Color.yellow);        
        panelCentro.setBackground(Color.blue);
        panelAbajo.setBackground(Color.red);        
        frame.setLayout(new BorderLayout(1,1));        
        frame.add(panelArriba, BorderLayout.NORTH);
        frame.add(panelCentro,BorderLayout.CENTER);
        frame.add(panelAbajo, BorderLayout.SOUTH);
        panelArriba.add(caja);        
        panelArriba.add(boton);        
        boton.addActionListener(even); 
        panelCentro.add(ta);
        frame.setSize(800, 600);          
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setVisible(true);          
    }  
}  