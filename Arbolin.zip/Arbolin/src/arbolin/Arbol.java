package arbolin;

import java.awt.Graphics;

public class Arbol {
    public static Nodo raiz = null;
    
    public void imprimir(Nodo cabeza){
        if(cabeza!=null){            
            imprimir(cabeza.hijoIzq);            
            imprimir(cabeza.hijoDer);
            cabeza.imprimir();
        }
    }
    public void paint(Graphics g, Nodo cabeza){
        if(cabeza!=null){            
            paint(g, cabeza.hijoIzq);            
            paint(g, cabeza.hijoDer);
            cabeza.paint(g);
        }
    }
    
    public void anadir(Nodo padre, Nodo nuevo){
        if(raiz==null){
            raiz = nuevo;
            raiz.posY = Configuracion.coorri;
            raiz.posX = (int)(Configuracion.anchoVe/2);
            raiz.nivel = 1;
            double d = (Math.pow(2, raiz.nivel));
            // int anchura = (int)(Ventana.parX/d);
            int anchura = (int)(Configuracion.anchoVe/d);            
            raiz.parX = anchura;   
            
            raiz.posYPapi = raiz.posY;
            raiz.posXPapi = raiz.posX;
            raiz.posXMia = raiz.posX;
            raiz.posYMia = raiz.posY;
            
        }
        else{
            if(padre!=null){
                // Hay que colocarlo por la IZQ
                if(padre.valor>nuevo.valor){
                    // Y se puede colocar por la IZQ
                    if(padre.hijoIzq==null){
                        padre.hijoIzq = nuevo;
                        nuevo.posY = padre.posY+Configuracion.coorri;
                        nuevo.nivel = padre.nivel+1;
                        nuevo.parX = (int)(padre.parX/2);
                        nuevo.posX = padre.posX-nuevo.parX;
                        
                        nuevo.posXPapi = padre.posX+20;
                        nuevo.posYPapi = padre.posY+40;                        
                        nuevo.posXMia = nuevo.posX+20;
                        nuevo.posYMia = nuevo.posY;
                        
                    }
                    else{
                        anadir(padre.hijoIzq, nuevo);
                    }
                }
                // Hay que colocarlo por la DER
                else{
                    // Y se puede colocar por la DER
                    if(padre.hijoDer==null){
                        padre.hijoDer = nuevo;
                        nuevo.posY = padre.posY+Configuracion.coorri;
                        nuevo.nivel = padre.nivel+1;                        
                        nuevo.parX = (int)(padre.parX/2);
                        nuevo.posX = padre.posX+nuevo.parX;
                        
                        nuevo.posXPapi = padre.posX+20;
                        nuevo.posYPapi = padre.posY+40;                        
                        nuevo.posXMia = nuevo.posX+20;
                        nuevo.posYMia = nuevo.posY;
                    }
                    else{
                        anadir(padre.hijoDer, nuevo);
                    }
                }
            }
        }
    }
    
}
