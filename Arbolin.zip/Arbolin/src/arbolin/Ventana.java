package arbolin;

import java.awt.Graphics;
import javax.swing.JFrame;

public class Ventana extends JFrame{
    public static int parX = 800;
    
    public Ventana(){
        super("Grafica Arbol");
        setVisible(true);
        setSize(Configuracion.anchoVe,Configuracion.largoVe);
    }
    
    public void paint(Graphics g){
        super.paint(g);
        Arbolin.objArbol.paint(g, Arbolin.n1);
    }
    
    public static void main(String[] args) {
        Arbolin p = new Arbolin();
        Ventana objV = new Ventana();
    }
    
}
