package arbolin;

import java.awt.Graphics;

public class Nodo {
    public Nodo hijoIzq = null;
    public int valor = 0;
    public Nodo hijoDer = null;
    public int nivel = 0;
    public int posX = 0;
    public int posY = 0;
    public int largo = 0;
    public int parX = 0;  
    
    public int posXPapi = 0;
    public int posYPapi = 0;
    public int posXMia = 0;
    public int posYMia = 0;
    
    
    public Nodo(int val){
        valor = val;
        posX = 400;
        posY = 100;
        largo = 40;
    }
    
    public void paint(Graphics g){
        g.drawOval(posX, posY, largo, largo);        
        g.drawLine(posXPapi, posYPapi, posXMia, posYMia);
    }
    
    public void imprimir(){
        System.out.println("valor "+valor+ " nivel"+nivel);
    }
    
}
