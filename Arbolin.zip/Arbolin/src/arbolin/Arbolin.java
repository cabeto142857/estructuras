package arbolin;

public class Arbolin {
    public static Arbol objArbol = new Arbol();
    public static Nodo n1 = new Nodo(500);
    public static Nodo n2 = new Nodo(250);
    public static Nodo n3 = new Nodo(750);
    public static Nodo n4 = new Nodo(125);
    public static Nodo n5 = new Nodo(320);
    public static Nodo n6 = new Nodo(600);
    public static Nodo n7 = new Nodo(800);
    public static Nodo n8 = new Nodo(60);
    public static Nodo n9 = new Nodo(180);
    public static Nodo n10 = new Nodo(290);
    public static Nodo n11 = new Nodo(400);
    public static Nodo n12 = new Nodo(550);
    public static Nodo n13 = new Nodo(700);
    public static Nodo n14 = new Nodo(780);
    public static Nodo n15 = new Nodo(900);
    
    public Arbolin(){
        objArbol.anadir(Arbol.raiz, n1);        
        objArbol.anadir(Arbol.raiz, n2);
        objArbol.anadir(Arbol.raiz, n3);
        objArbol.anadir(Arbol.raiz, n4);
        objArbol.anadir(Arbol.raiz, n5);
        objArbol.anadir(Arbol.raiz, n6);
        objArbol.anadir(Arbol.raiz, n7);
        objArbol.anadir(Arbol.raiz, n8);
        objArbol.anadir(Arbol.raiz, n9);
        objArbol.anadir(Arbol.raiz, n10);
        objArbol.anadir(Arbol.raiz, n11);
        objArbol.anadir(Arbol.raiz, n12);
        objArbol.anadir(Arbol.raiz, n13);
        objArbol.anadir(Arbol.raiz, n14);
        objArbol.anadir(Arbol.raiz, n15);
        objArbol.imprimir(Arbol.raiz);
    }

    public static void main(String[] args) {
        Arbolin p = new Arbolin();
    }
    
}
