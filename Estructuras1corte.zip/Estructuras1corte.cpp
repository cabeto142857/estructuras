#include <iostream>
using namespace std;

     class List{
      private:
      int dato; 
      List *sig; 
     
 public:
 	
 	
 	
 	void crear(List *&ini){ 
      int dato=142857;//cualquier n�mero diferente a cero para arrancar
      while(dato!=0){
        cout<<"Digite CERO para salir o INGRESE DATO................ ";
        cin>>dato;
        if(dato!=0){
          if(ini==NULL){ 
            inicio(ini, dato);
            }
          else{
            nuevoNodo(ini, dato);
          }
          }
        
      }
    }
    
	void inicio(List *&ini, int dato){ 
      
      ini=new List;
      
      ini->dato=dato;

      ini->sig=NULL; // se escribe NULL para asignar el  ultimo
    }
    
	
	void nuevoNodo(List *&ini, int dato){ 
      List *aux=ini; //este es el apuntador para buscar el Null y agregar un nuevo nodo al final
      while(aux->sig!=NULL){ //Busca Null para conocer elnodo final de la lista
        aux=aux->sig;
      }
      aux->sig=new List;
      aux=aux->sig;
      aux->dato=dato; 
      
      
      aux->sig=NULL;
    }
    
    
	
    
    
	void mostrar(List *&ini){ 
      List *aux=ini;  //Ubicar apuntador auxiliar al inicio
      while(aux!=NULL){ //El auxiliar recorre la lista
        cout<<" "<<aux->dato<<endl;
        aux=aux->sig;
      }
    }
    
    
    
           void duplicados(List *&ini){
            List *aux=ini;
            while(aux!=NULL && aux->sig!=NULL){
             List *aux1=aux; 
             List *elemento=aux->sig; 
                 while (elemento!=NULL){ 
                  if(elemento->dato == aux->dato){ 
                  aux1->sig=elemento->sig; // se enlaza el nodo anterior al siguiente para eliminar el nodo sobrante
                  delete elemento; // Se elimina el dato duplicado.
                  elemento=aux1->sig;
    
                  }else{ 
                  aux1=elemento; 
                  elemento=elemento->sig;
      }
    }
                  aux=aux->sig;
  }
}

	
};
    
                 int main(){
                    List *ini=NULL, objeto;
                    objeto.crear(ini);
                    cout<<"La lista completa es:"<<endl;
                    objeto.mostrar(ini);
                    objeto.duplicados(ini);
                    cout<<"La lista sin numeros duplicados es:"<<endl;
                    objeto.mostrar(ini);
 
}
