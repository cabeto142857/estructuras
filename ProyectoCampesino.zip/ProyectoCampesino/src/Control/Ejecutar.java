/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

/**
 *
 * @author Carlo
 */


          import Vista.InOut;

     public class Ejecutar {
    
         public static void main(String[] args) {
        InOut objetoin = new InOut();
        objetoin.mostrarMenuPrincipal();
    }
}
