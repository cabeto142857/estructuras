package arbolin;

public class Configuracion {
    public static int coorri = 130;
    public static int anchoVe = 1700;
    public static int largoVe = 800;
    
    
}
