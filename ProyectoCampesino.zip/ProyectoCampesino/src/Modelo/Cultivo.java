/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Carlo
 */


public class Cultivo {
    private String cedulaCampesino;
    private String tipoCultivo;
    
    private String nombredegasto;
    private double valordegasto;

    public Cultivo(String cedulaCampesino, String tipoCultivo) {
        
        
        
       this.cedulaCampesino = cedulaCampesino;
        this.tipoCultivo = tipoCultivo;
        this.nombredegasto=nombredegasto;
        this.valordegasto=valordegasto;
        
        
        
        
        
    }

    @Override
    public String toString() {
        return cedulaCampesino + "," + tipoCultivo+","+nombredegasto+"*"+valordegasto;
    }
    
    
    
    public void guardarCultivoEnArchivo(Cultivo cultivo) {
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/cultivos.txt", true))) {
            writer.write(cultivo.toString());
            writer.newLine();
        } 
        catch (IOException e) {
            
        }
    }
}


