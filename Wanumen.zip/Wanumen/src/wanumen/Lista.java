package wanumen;
public class Lista {
    Nodo primero = null;
    Nodo ultimo = null;
    public void anadir(Nodo nodin){
        if(nodin!=null){
            if(primero==null){
                primero = nodin;
                ultimo = nodin;
            }
            else{
                ultimo.sig = nodin;
                ultimo = nodin;
            }
        }
    }
    
    public void imprimir(){
        Nodo correr = primero;
        while(correr!=null){
            correr.imprimir();
            correr = correr.sig;
        }
    }
    
    public String devolverLista(){
        String cad = "";
        Nodo correr = primero;
        while(correr!=null){
            cad = cad + correr.getNombre()+" \n";
            correr = correr.sig;
        }
        return cad;
    }    
    
}
