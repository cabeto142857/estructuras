package wanumen;

public class Wanumen {    
    public static Lista objLista = new Lista();    
    public Wanumen(){
        Ventana.iniciarVentana();
    }
    public static void main(String[] args) {
        Wanumen P = new Wanumen();

    }
    
}
